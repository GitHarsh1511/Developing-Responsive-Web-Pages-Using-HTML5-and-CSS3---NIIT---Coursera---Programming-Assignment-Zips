const path = require('path');
const { readFileSync } = require('fs');
const { JSDOM } = require('jsdom');

let document;

beforeAll(() => {
  const htmlFile = readFileSync(path.join(__dirname, '../index.html'), 'utf-8');
  const dom = new JSDOM(htmlFile, { contentType: 'text/html' });
  document = dom.window.document;
  global.dom = dom;
});

test('Should check that embedded style sheets are not used', () => {
  const styleTag = document.getElementsByTagName('style');
  expect(styleTag.length).toBe(0);
});

test('Should check if link tag is used referring to an external file within the project', () => {
  const linkTags = document.getElementsByTagName('link');
  let localStylesheetFound = false;
  for (let i = 0; i < linkTags.length; i++) {
    const hrefValue = linkTags[i].getAttribute('href');
    if (hrefValue && !hrefValue.startsWith('http')) {
      localStylesheetFound = true;
      break;
    }
  }
  expect(localStylesheetFound).toBe(true);
});

test('Should check if bootstrap cdn libraries are used', () => {
  const linkTags = document.getElementsByTagName('link');
  let bootstrapFound = false;
  for (let i = 0; i < linkTags.length; i++) {
    const hrefValue = linkTags[i].getAttribute('href');
    if (hrefValue && hrefValue.includes('bootstrap.min.css')) {
      bootstrapFound = true;
      break;
    }
  }
  expect(bootstrapFound).toBe(true);
});

test('Should check that class/id values should not have dot/hash', () => {
  const divElements = document.getElementsByTagName('div');
  for (let i = 0; i < divElements.length; i++) {
    const className = divElements[i].getAttribute('class');
    const idName = divElements[i].getAttribute('id');
    if (className) expect(className).not.toMatch(/^(\.|#)/);
    if (idName) expect(idName).not.toMatch(/^(\.|#)/);
  }
});

test('Should check if there is a nav semantic tag that uses bootstrap class called navbar', () => {
  const navElements = document.getElementsByTagName('nav');
  let navbarClassFound = false;
  for (let i = 0; i < navElements.length; i++) {
    const classNames = navElements[i].getAttribute('class');
    if (classNames && classNames.includes('navbar')) {
      navbarClassFound = true;
      break;
    }
  }
  expect(navbarClassFound).toBe(true);
});