const path = require('path');
const { readFileSync } = require('fs');
const { JSDOM } = require('jsdom');

let document;

beforeAll(() => {
    const htmlFile = readFileSync(path.join(__dirname, '../index.html'), 'utf-8');
    const dom = new JSDOM(htmlFile, { contentType: 'text/html' });
    document = dom.window.document;
    global.dom = dom;
});

test('Should check that embedded style sheets are not used', () => {
    const styleTag = document.getElementsByTagName('style');
    expect(styleTag.length).toEqual(0);
});

test('Should check if link tag is used referring to an external file within the project', () => {
    const linkTag = document.getElementsByTagName('link');
    let href_value;
    if (linkTag.length > 0) {
        for (let i = 0; i < linkTag.length; i++) {
            href_value = linkTag[i].attributes.getNamedItem("href").value;
            if (!href_value.match(/http/)) {
                break;
            }
        }
        expect(href_value).not.toMatch(/http/);
    }
});

test('Should check if there are main, nav and ul semantic elements present', () => {
    const main_element = document.getElementsByTagName('main');
    expect(main_element.length).toEqual(1);
    const nav_element = document.getElementsByTagName('nav');
    expect(nav_element.length).toEqual(1);
    const list_element = document.getElementsByTagName('ul');
    expect(list_element.length).toBeGreaterThanOrEqual(1);
});

test('should check if 6 anchor elements are present and are children of nav', () => {
    const navElement = document.getElementById('navigation');
    const anchorElements = navElement.getElementsByTagName('a');

    // Check if there are exactly 6 anchor elements
    expect(anchorElements.length).toEqual(6);

    // Check if each anchor element's parent is an LI
    for (let anchor of anchorElements) {
        const parent = anchor.parentElement.nodeName; // Get the parent node name
        expect(parent).toEqual('LI'); // Each anchor should be within an LI
    }
});

test('Should check if nav contains the 6 list items', () => {
    const navElement = document.getElementById('navigation');
    const listItems = navElement.getElementsByTagName('li');
    expect(listItems.length).toEqual(6); // Check if there are 6 list items in nav
});

test('Should check class/id values should not have dot/hash', () => {
    let attr_value = document.getElementsByTagName('div')[0].attributes[0].value;
    expect(attr_value).not.toMatch(/^(\.|#)/);
});
